import os
import subprocess
import argparse
import torch
import gc
import time
from tqdm import tqdm

def train_stock_models(data_dir, pred_len=11, seq_len=120, label_len=24, batch_size=8, patience=10):
    """Train TimeLLM models for each stock with improved parameters for financial data"""
    stocks = [f.split('.')[0] for f in os.listdir(data_dir) if f.endswith('.csv')]
   
    print(f"Found {len(stocks)} stocks in {data_dir}")
   
    # Create prompt_bank directory if it doesn't exist
    prompt_bank_dir = './dataset/prompt_bank'
    os.makedirs(prompt_bank_dir, exist_ok=True)
    
    # Make sure checkpoints directory exists
    os.makedirs('./checkpoints', exist_ok=True)
   
    # Check for prompt files
    for stock in stocks:
        prompt_file = os.path.join(prompt_bank_dir, f"{stock}.txt")
        if not os.path.exists(prompt_file):
            print(f"Warning: No prompt file found for {stock}, check if it was manually created")
        
        # Pre-create checkpoint directory for this stock
        checkpoint_path = f'./checkpoints/long_term_forecast_{stock}_{seq_len}_{pred_len}_TimeLLM_{stock}_ftMS_sl{seq_len}_ll{label_len}_pl{pred_len}_dm32_nh8_el2_dl1_df128_fc3_ebtimeF_Exp_0-TimeLLM-{stock}'
        os.makedirs(checkpoint_path, exist_ok=True)
   
    for stock in tqdm(stocks, desc="Training models"):
        # Create a unique model ID and comment
        model_id = f"{stock}_{seq_len}_{pred_len}"
        model_comment = f"TimeLLM-{stock}"
       
        # Use 'close' as the target column
        target_col = 'close'
       
        # Build command with financial time series optimized parameters
        cmd = [
            "python", "run_main.py",
            "--task_name", "long_term_forecast",
            "--is_training", "1",
            "--root_path", data_dir,
            "--data_path", f"{stock}.csv",
            "--model_id", model_id,
            "--model", "TimeLLM",
            "--data", stock,
            "--features", "MS",  # Multivariate input, univariate output
            "--seq_len", str(seq_len),
            "--label_len", str(label_len),
            "--pred_len", str(pred_len),
            "--factor", "3",
            "--enc_in", "9",  # 9 feature columns excluding date and target
            "--dec_in", "9",
            "--c_out", "1",   # Single output (close price)
            "--des", "Exp",
            "--itr", "1",
            "--d_model", "32",  # Increased from 16
            "--d_ff", "128",    # Increased from 64
            "--batch_size", str(batch_size),
            "--learning_rate", "0.0005",
            "--llm_model", "GPT2",
            "--llm_dim", "768",
            "--llm_layers", "4",
            "--train_epochs", "100",
            "--patience", str(patience),
            "--model_comment", model_comment,
            "--target", target_col,
            "--prompt_domain", "0"
        ]
       
        print(f"\nTraining model for {stock}...")
        print(" ".join(cmd))
       
        # Run the command
        subprocess.run(cmd)
        
        # Explicit cleanup after each training run
        print(f"Completed training for {stock}. Cleaning up resources...")
        gc.collect()
        
        # Force GPU memory cleanup
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            
        # Brief pause to let system stabilize
        time.sleep(10)
        
        print(f"Ready for next model")

def train_single_stock(stock, data_dir, pred_len=11, seq_len=120, label_len=24, batch_size=8, patience=10):
    """Train TimeLLM model for a single stock (alternative to training all at once)"""
    
    # Create directories
    prompt_bank_dir = './dataset/prompt_bank'
    os.makedirs(prompt_bank_dir, exist_ok=True)
    os.makedirs('./checkpoints', exist_ok=True)
    
    # Create a unique model ID and comment
    model_id = f"{stock}_{seq_len}_{pred_len}"
    model_comment = f"TimeLLM-{stock}"
    
    # Pre-create checkpoint directory
    checkpoint_path = f'./checkpoints/long_term_forecast_{stock}_{seq_len}_{pred_len}_TimeLLM_{stock}_ftMS_sl{seq_len}_ll{label_len}_pl{pred_len}_dm32_nh8_el2_dl1_df128_fc3_ebtimeF_Exp_0-TimeLLM-{stock}'
    os.makedirs(checkpoint_path, exist_ok=True)
    
    # Use 'close' as target
    target_col = 'close'
    
    # Build command with financial parameters
    cmd = [
        "python", "run_main.py",
        "--task_name", "long_term_forecast",
        "--is_training", "1",
        "--root_path", data_dir,
        "--data_path", f"{stock}.csv",
        "--model_id", model_id,
        "--model", "TimeLLM",
        "--data", stock,
        "--features", "MS",
        "--seq_len", str(seq_len),
        "--label_len", str(label_len),
        "--pred_len", str(pred_len),
        "--factor", "3",
        "--enc_in", "9",
        "--dec_in", "9",
        "--c_out", "1",
        "--des", "Exp",
        "--itr", "1",
        "--d_model", "32",
        "--d_ff", "128",
        "--batch_size", str(batch_size),
        "--learning_rate", "0.0005",
        "--llm_model", "GPT2",
        "--llm_dim", "768",
        "--llm_layers", "4",
        "--train_epochs", "100",
        "--patience", str(patience),
        "--model_comment", model_comment,
        "--target", target_col,
        "--prompt_domain", "0"
    ]
    
    print(f"Training model for {stock}...")
    print(" ".join(cmd))
    
    subprocess.run(cmd)
    print(f"Completed training for {stock}")

def main():
    parser = argparse.ArgumentParser(description='Train TimeLLM models for stocks')
    parser.add_argument('--data_dir', type=str, default='./dataset/stocks_formatted/', help='Directory with formatted stock data')
    parser.add_argument('--pred_len', type=int, default=11, help='Prediction length')
    parser.add_argument('--seq_len', type=int, default=120, help='Sequence length')
    parser.add_argument('--label_len', type=int, default=24, help='Label length')
    parser.add_argument('--batch_size', type=int, default=8, help='Batch size')
    parser.add_argument('--patience', type=int, default=10, help='Early stopping patience')
    parser.add_argument('--stock', type=str, help='Train a single stock (optional)')
    args = parser.parse_args()
    
    # If a specific stock is provided, train just that one
    if args.stock:
        train_single_stock(args.stock, args.data_dir, args.pred_len, args.seq_len, 
                          args.label_len, args.batch_size, args.patience)
    else:
        # Otherwise train all stocks in the directory
        train_stock_models(args.data_dir, args.pred_len, args.seq_len, 
                          args.label_len, args.batch_size, args.patience)

if __name__ == "__main__":
    main()